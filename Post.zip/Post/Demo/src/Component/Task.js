import React from 'react'
import TopNavigation from "./TopNavigation";

function Task() {
    return (
        <div>
            <TopNavigation />
            <h2>Task</h2>
        </div>
    )
}

export default Task