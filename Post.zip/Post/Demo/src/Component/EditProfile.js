import React from 'react'
import TopNavigation from "./TopNavigation";

function EditProfile() {
    return (
        <div>
            <TopNavigation />
            <h2>Edit Profile</h2>
        </div>
    )
}

export default EditProfile